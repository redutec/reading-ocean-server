package com.redutec.core.repository.v1;

import com.redutec.core.entity.v1.BdtArticle;
import com.redutec.core.entity.v1.BdtArticleAttachFile;
import com.redutec.core.meta.AttachFileValue;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;

import java.util.Optional;

public interface BdtArticleAttachFileRepository extends JpaRepository<BdtArticleAttachFile, Integer>, JpaSpecificationExecutor<BdtArticleAttachFile> {
    Optional<BdtArticleAttachFile> findByArticleAndAttachFileValue(BdtArticle bdtArticle, AttachFileValue attachFileValue);

    void deleteByArticle(BdtArticle article);
}